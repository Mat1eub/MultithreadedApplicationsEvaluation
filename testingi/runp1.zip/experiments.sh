#!/usr/bin/bash
make all